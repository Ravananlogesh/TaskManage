package database

import (
	"fmt"
	"log"
	"tasks/config"
	"tasks/internal/models"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var DB *gorm.DB

func ConnectDatabase() error {
	var cf models.Config

	err := config.LoadTOML("config.toml", &cf)
	if err != nil {
		return err
	}
	dsn := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=%s", cf.Database.Host, cf.Database.Port, cf.Database.User,
		cf.Database.Pass, cf.Database.Name, cf.Database.Sslmode)

	// Connect to PostgreSQL
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
		return err
	}

	// AutoMigrate models
	err = db.AutoMigrate(&models.User{}, &models.Task{})
	if err != nil {
		log.Fatalf("Database migration failed: %v", err)
		return err
	}

	DB = db

	return nil
}
