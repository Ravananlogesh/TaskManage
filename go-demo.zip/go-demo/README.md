# Go API Project

## Overview
A RESTful API built with Golang that includes authentication, database operations, and more.

---

## 🛠 Setup

### **1️⃣ Install Dependencies**
```sh
go mod tidy
